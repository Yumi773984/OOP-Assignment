package assesmentjava; // Declares the package name

public class MainClass {

	public static void main(String[] args) {
		// Entry point of the Java program
		
		// Create an instance of the TurtleGraphics class
		// This will launch the Turtle Graphics GUI window
		TurtleGraphics Main = new TurtleGraphics();
		
		// TODO: Additional logic or enhancements can be added here if needed
	}
}