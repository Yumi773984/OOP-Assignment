package assesmentjava;

import java.awt.*; // GUI and graphics
import javax.swing.*; // GUI components like JFrame, JMenu, etc.
import java.io.*; // File I/O
import javax.imageio.ImageIO; // For saving images
import java.awt.image.BufferedImage; // For image buffer
import java.util.ArrayList;
import java.util.List;

// Import the LBUGraphics base class (from Leeds Beckett University)
import uk.ac.leedsbeckett.oop.LBUGraphics;

public class TurtleGraphics extends LBUGraphics {

	// GUI components and state trackers
	private JFrame mainframe;
	private List<String> commandHistory = new ArrayList<>();
	private JTextArea commandTextArea;
	private boolean hasUnsavedChanges = false;
	private boolean isMaximized = false;
	private Dimension originalSize;
	private Point originalLocation;

	public TurtleGraphics() {
		// Set up main window
		mainframe = new JFrame("Turtle Graphics");
		mainframe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		mainframe.setLayout(new FlowLayout());
		mainframe.add(this); // Add the turtle drawing panel itself

		// Set up command history area on the left
		commandTextArea = new JTextArea(24, 20);
		commandTextArea.setLineWrap(true);
		commandTextArea.setWrapStyleWord(true);

		JScrollPane scrollPane = new JScrollPane(commandTextArea);
		JPanel historyPanel = new JPanel(new BorderLayout());
		historyPanel.add(new JLabel("Command History"), BorderLayout.NORTH);
		historyPanel.add(scrollPane, BorderLayout.CENTER);
		mainframe.add(historyPanel, BorderLayout.WEST);

		// Create menu bar
		JMenuBar menuBar = new JMenuBar();

		// ----- File Menu -----
		JMenu fileMenu = new JMenu("File");
		JMenuItem newPage = new JMenuItem("New file");
		JMenuItem saveImageItem = new JMenuItem("Save Image");
		JMenuItem loadImageItem = new JMenuItem("Load Image");
		JMenuItem saveCommandItem = new JMenuItem("Save Command");
		JMenuItem loadCommandItem = new JMenuItem("Load Commands");

		// Add actions to file menu items
		newPage.addActionListener(e -> newFile());
		saveImageItem.addActionListener(e -> saveImage());
		loadImageItem.addActionListener(e -> loadImage());
		saveCommandItem.addActionListener(e -> saveCommand());
		loadCommandItem.addActionListener(e -> loadCommand());

		// Add file items to File menu
		fileMenu.add(newPage);
		fileMenu.addSeparator();
		fileMenu.add(saveImageItem);
		fileMenu.add(loadImageItem);
		fileMenu.addSeparator();
		fileMenu.add(saveCommandItem);
		fileMenu.add(loadCommandItem);

		// ----- Edit Menu -----
		JMenu editMenu = new JMenu("Edit");
		JMenuItem penDownItem = new JMenuItem("Pen down");
		JMenuItem penUpItem = new JMenuItem("Pen up");
		JMenuItem clearItem = new JMenuItem("Clear");
		JMenuItem resetItem = new JMenuItem("Reset");

		// Add actions to edit menu items
		penDownItem.addActionListener(e -> processCommand("pendown"));
		penUpItem.addActionListener(e -> processCommand("penup"));
		clearItem.addActionListener(e -> processCommand("clear"));
		resetItem.addActionListener(e -> processCommand("reset"));

		// Add edit items to Edit menu
		editMenu.add(penDownItem);
		editMenu.add(penUpItem);
		editMenu.addSeparator();
		editMenu.add(clearItem);
		editMenu.add(resetItem);

		// ----- Help Menu -----
		JMenu helpMenu = new JMenu("Help");
		JMenuItem aboutItem = new JMenuItem("About");
		JMenuItem aboutCommandsItem = new JMenuItem("About Commands");

		// Add actions to help items
		aboutItem.addActionListener(e -> about_me());
		aboutCommandsItem.addActionListener(e -> showCommandHelp());

		// Add help items to Help menu
		helpMenu.add(aboutItem);
		helpMenu.add(aboutCommandsItem);

		// Add all menus to the menu bar
		menuBar.add(fileMenu);
		menuBar.add(editMenu);
		menuBar.add(helpMenu);
		mainframe.setJMenuBar(menuBar);

		// Display the frame
		mainframe.pack();
		mainframe.setVisible(true);
	}


	// Display a guide to all supported commands in the Turtle Graphics system
	private void showCommandHelp() {
	    String helpText = "🧭 TURTLE GRAPHICS COMMAND GUIDE\n"
	            + "=====================================\n\n"

	            + "➡️ MOVEMENT\n"
	            + "-------------------------------------\n"
	            + "move [value]           → Move forward by the given amount.\n"
	            + "reverse [value]        → Move backward (defaults to 100 if unspecified).\n"
	            + "left [angle]           → Rotate the turtle to the left (default is 90°).\n"
	            + "right [angle]          → Rotate the turtle to the right (default is 90°).\n\n"

	            + "✏️ PEN & COLOURS\n"
	            + "-------------------------------------\n"
	            + "penup                  → Lift the pen (no drawing on movement).\n"
	            + "pendown                → Lower the pen (drawing is enabled).\n"
	            + "pen r g b              → Set pen color using RGB values (0–255).\n"
	            + "red / blue / green     → Quick color commands to change pen color.\n"
	            + "pink / cyan / black    → Additional predefined color options.\n\n"

	            + "📐 SHAPES\n"
	            + "-------------------------------------\n"
	            + "square [size]          → Draw a square with each side of given size.\n"
	            + "triangle [side]        → Create a triangle with all equal sides.\n"
	            + "triangle a b c         → Draw triangle with custom side lengths.\n"
	            + "circle [radius]        → Generate a circle with specified radius.\n"
	            + "circle a b c           → Extension: draw curve using 3 parameters radius, x point and y point on grid.\n\n"

	            + "🛠 BASIC TOOLS\n"
	            + "-------------------------------------\n"
	            + "clear                  → Wipes the canvas clean.\n"
	            + "reset                  → Repositions the turtle to the start point.\n"
	            + "about                  → Shows app info and author.\n\n";

	    JTextArea helpArea = new JTextArea(helpText);
	    helpArea.setEditable(false);
	    helpArea.setFont(new Font("Monospaced", Font.PLAIN, 12));

	    JScrollPane scrollPane = new JScrollPane(helpArea);
	    scrollPane.setPreferredSize(new Dimension(540, 430));

	    JOptionPane.showMessageDialog(
	            this,
	            scrollPane,
	            "📖 Help - Command Reference",
	            JOptionPane.PLAIN_MESSAGE
	    );
	}
	private void  about_me() {
	    JOptionPane.showMessageDialog(
	            this,
	            "Turtle Graphics - Version 6.0\nDeveloped by Yuri\nPowered by LBU Graphics",
	            "About",
	            JOptionPane.INFORMATION_MESSAGE
	    );
	}

	@Override 
	public void about() {
		clear ();
		
		
		reset();
		
		//Y
	    drawOff();
	    forward(100);
	    right();
	    forward(300);
	    right();
	     
	    setStroke(5);
	    setPenColour(Color.red);
	    drawOn();
	    forward(200);
	    drawOff();
	    forward(-80);
	    left(45);
	    drawOn();
	    forward(100);
	    
	    //U
	    drawOff();
	    right();
	    forward(100);
	    right();
	    
	    right();
	    left(45);
	    left();
	    forward(30);
	    right();
	    forward(60);
	    setPenColour(Color.green);
	    drawOn();
	    forward(200);
	    left();
	    forward(80);
	    left();
	    forward(200);
	    //R
	    drawOff();
	    forward(-200);
	    right();
	    forward(40);
	    left();
	    setPenColour(Color.pink);
	    drawOn();
	    forward(200);
	    right(90);
	    for (int i = 0; i < 18; i++) {
	        forward(9);
	        right(10);
	    }

	    drawOff();
	    left(125);
	    forward(10);
	    drawOn();
	    forward(125);
	    
	 //   I
	    drawOff();
	    left(60);
	     forward(40);
	     left(45);
	     left(15);
	     left(10);
	     left(15);
	     setPenColour(Color.yellow);
	     drawOn();
	     
	     forward(200);
	}

	
	// Create new file (clears everything and resets)
	private void newFile() {
		if (checkUnsavedChanges()) return;
		clear();
		reset();
		commandTextArea.setText("");
		commandHistory.clear();
		hasUnsavedChanges = false;
		JOptionPane.showMessageDialog(null, "Please enter command");
	}

	// Save the canvas as an image (JPG/PNG)
	private void saveImage() {
		JFileChooser fileChooser = new JFileChooser();
		fileChooser.setDialogTitle("Save Image");

		// Set file filters for image types
		fileChooser.addChoosableFileFilter(new javax.swing.filechooser.FileNameExtensionFilter("JPG image (*.jpg)", "jpg"));
		fileChooser.addChoosableFileFilter(new javax.swing.filechooser.FileNameExtensionFilter("PNG image (*.png)", "png"));
		fileChooser.setAcceptAllFileFilterUsed(false);
		fileChooser.setFileFilter(fileChooser.getChoosableFileFilters()[0]);

		// Show save dialog
		int userSelection = fileChooser.showSaveDialog(this);
		if (userSelection == JFileChooser.APPROVE_OPTION) {
			File selectedFile = fileChooser.getSelectedFile();
			String extension = "jpg";

			// Check selected file type
			String selectedDescription = fileChooser.getFileFilter().getDescription();
			if (selectedDescription.contains("PNG")) {
				extension = "png";
			}

			// Ensure correct extension
			if (!selectedFile.getName().toLowerCase().endsWith("." + extension)) {
				selectedFile = new File(selectedFile.getAbsolutePath() + "." + extension);
			}

			try {
				// Capture canvas as image
				BufferedImage image = new BufferedImage(getWidth(), getHeight(), BufferedImage.TYPE_INT_RGB);
				Graphics2D g2 = image.createGraphics();
				paintAll(g2);
				ImageIO.write(image, extension, selectedFile);

				// Clear screen after saving
				clear();
				reset();
				JOptionPane.showMessageDialog(null, "Image saved to: " + selectedFile.getAbsolutePath());
				hasUnsavedChanges = false;
			} catch (IOException ex) {
				JOptionPane.showMessageDialog(null, "Failed to save image");
			}
		}
	}
    
		
	// Load and display an image in a dialog
	private void loadImage() {
		if (checkUnsavedChanges()) return;

		JFileChooser fileChooser = new JFileChooser();
		fileChooser.setDialogTitle("Load Image");
		fileChooser.setAcceptAllFileFilterUsed(true); // Allow all image types

		if (fileChooser.showOpenDialog(this) == JFileChooser.APPROVE_OPTION) {
			File file = fileChooser.getSelectedFile();
			try {
				BufferedImage loadedImage = ImageIO.read(file);
				if (loadedImage != null) {
					// Display loaded image in a dialog box
					JDialog imageDialog = new JDialog(mainframe, "Loaded Image", false);
					imageDialog.setLayout(new BorderLayout());

					JLabel imageLabel = new JLabel(new ImageIcon(loadedImage));
					JScrollPane scrollPane = new JScrollPane(imageLabel);
					imageDialog.add(scrollPane, BorderLayout.CENTER);

					JButton closeButton = new JButton("Close");
					closeButton.addActionListener(e -> imageDialog.dispose());
					JPanel buttonPanel = new JPanel();
					buttonPanel.add(closeButton);
					imageDialog.add(buttonPanel, BorderLayout.SOUTH);

					imageDialog.setSize(600, 500);
					imageDialog.setLocationRelativeTo(this);
					imageDialog.setVisible(true);

					JOptionPane.showMessageDialog(null, "Image loaded: " + file.getName());
					clear();
					reset();
					hasUnsavedChanges = false;
				} else {
					JOptionPane.showMessageDialog(null, "Failed to load image: Unsupported format or corrupted file");
				}
			} catch (IOException e) {
				JOptionPane.showMessageDialog(null, "Error loading image: " + e.getMessage());
			}
		}
	}

	// Save the command history to a .txt file
	private void saveCommand() {
		JFileChooser fileChooser = new JFileChooser();
		fileChooser.setDialogTitle("Save commands");
		fileChooser.setFileFilter(new javax.swing.filechooser.FileNameExtensionFilter("Text files (*.txt)", "txt"));

		if (fileChooser.showSaveDialog(this) == JFileChooser.APPROVE_OPTION) {
			File file = fileChooser.getSelectedFile();

			// Ensure file ends with .txt
			if (!file.getName().toLowerCase().endsWith("txt")) {
				file = new File(file.getAbsolutePath() + ".txt");
			}

			try (PrintWriter writer = new PrintWriter(file)) {
				for (String cmd : commandHistory) {
					writer.println(cmd);
				}
				clear();
				reset();
				JOptionPane.showMessageDialog(null, "All commands saved to " + file.getAbsolutePath());
				hasUnsavedChanges = false;
			} catch (IOException e) {
				JOptionPane.showMessageDialog(null, "Error saving commands: " + e.getMessage());
			}
		}
	}

	// Load and execute commands from a text file
	private void loadCommand() {
		if (checkUnsavedChanges()) return;

		JFileChooser fileChooser = new JFileChooser();
		fileChooser.setDialogTitle("Load commands");

		if (fileChooser.showOpenDialog(this) == JFileChooser.APPROVE_OPTION) {
			File file = fileChooser.getSelectedFile();
			StringBuilder loadedCommands = new StringBuilder();

			try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
				clear();
				reset();
				commandHistory.clear();

				String line;
				while ((line = reader.readLine()) != null) {
					if (!line.trim().isEmpty()) {
						commandHistory.add(line);
						loadedCommands.append(line).append("\n");

						commandTextArea.setText(loadedCommands.toString());
						processCommand(line);
						repaint();

						// Slight delay between commands for visualization
						try {
							Thread.sleep(100);
						} catch (InterruptedException e) {
							Thread.currentThread().interrupt();
						}
					}
				}
				JOptionPane.showMessageDialog(null, "Commands loaded and executed from " + file.getAbsolutePath());
			} catch (IOException e) {
				JOptionPane.showMessageDialog(null, "Error loading commands: " + e.getMessage());
			}
		}
	}

	// Ask the user if they want to proceed when unsaved changes exist
	private boolean checkUnsavedChanges() {
		if (hasUnsavedChanges) {
			int option = JOptionPane.showConfirmDialog(
				this,
				"You have unsaved changes. Do you want to proceed?",
				"Unsaved Changes",
				JOptionPane.YES_NO_OPTION,
				JOptionPane.WARNING_MESSAGE
			);
			return option != JOptionPane.YES_OPTION; // true = don't proceed
		} else {
			return false;
		}
	}

	// Draw a square and return turtle to original state
	private void drawSquare(int length) {
		Point startPos = new Point(getxPos(), getyPos());
		int startHeading = getDirection();
		boolean wasPenDown = getPenState();

		drawOn();
		for (int i = 0; i < 4; i++) {
			forward(length);
			right(90);
		}
		if (!wasPenDown) drawOff();

		// Return to original position and direction
		setxPos(startPos.x);
		setyPos(startPos.y);
		pointTurtle(startHeading);
	}

	// Validate color component values (0–225 allowed)
	private boolean isValidColor(int value) {
		return value >= 0 && value <= 225;
	}

	// Draw an equilateral triangle
	private void drawEquilateralTriangle(int size) {
		if (size <= 0) {
			JOptionPane.showMessageDialog(null, "Size must be positive");
			return;
		}
		boolean wasDrawing = getPenState();
		drawOn();
		for (int i = 0; i < 3; i++) {
			forward(size);
			right(120);
		}
		if (!wasDrawing) {
			drawOff();
		}
	}

	// Draw a scalene triangle based on side lengths a, b, c
	private void drawScaleneTriangle(int a, int b, int c) {
		if (a <= 0 || b <= 0 || c <= 0) {
			JOptionPane.showMessageDialog(null, "All sides must be positive");
			return;
		}
		// Check triangle inequality
		if (a + b <= c || a + c <= b || b + c <= a) {
			JOptionPane.showMessageDialog(null, "Invalid triangle - sides violate triangle inequality");
			return;
		}

		boolean wasDrawing = getPenState();
		int startX = getxPos();
		int startY = getyPos();
		drawOn();

		// Use Law of Cosines to calculate angles
		double angleA = Math.toDegrees(Math.acos((b*b + c*c - a*a) / (2.0 * b * c)));
		double angleB = Math.toDegrees(Math.acos((a*a + c*c - b*b) / (2.0 * a * c)));
		double angleC = 180 - angleA - angleB;

		int A = (int) Math.round(180 - angleA);
		int B = (int) Math.round(180 - angleB);

		// Draw triangle sides
		forward(c);
		right(A);
		forward(a);
		right(B);
		forward(b);

		// Manually close triangle if turtle ends up slightly off due to rounding
		if (Math.hypot(getxPos() - startX, getyPos() - startY) > 2) {
			drawLine(getPenColour(), getxPos(), getyPos(), startX, startY);
			setxPos(startX);
			setyPos(startY);
		}

		if (!wasDrawing) drawOff();
	}

	@Override
	public void processCommand(String command) {
		// Override the abstract method from LBUGraphics
		System.out.println("command: " + command);
		commandHistory.add(command);

		String processedCmd = command.toLowerCase().trim();

		// Mark changes unless it's a passive command
		if (!processedCmd.equals("about") && !processedCmd.equals("clear")) {
			hasUnsavedChanges = true;
		}

		try {
			// Built-in 'about' command
			if (processedCmd.equals("about")) {
				about();
			}

			// Pen control
			else if (processedCmd.equals("pendown")) {
				drawOn();
			} else if (processedCmd.equals("penup")) {
				drawOff();
			}

			// Movement - forward
			else if (processedCmd.startsWith("move")) {
				String[] parts = processedCmd.split(" ");
				if (parts.length < 2) {
					JOptionPane.showMessageDialog(null, "Missing parameter: Please enter a distance (e.g., move 100).");
			        return;
				} else {
					try {
						int x = getxPos();
						int y = getyPos();
						int distance = Integer.parseInt(parts[1]);

						// Calculate new position
						int newX = x + (int) (distance * Math.sin(Math.toRadians(getDirection())));
						int newY = y - (int) (distance * Math.cos(Math.toRadians(getDirection())));

						// Boundary check
						if (newX < 0 || newX > getWidth() || newY < 0 || newY > getHeight()) {
							JOptionPane.showMessageDialog(null, "Cannot move turtle off screen");
							return;
						}
						forward(distance);
					} catch (NumberFormatException e) {
						JOptionPane.showMessageDialog(null, "Invalid number format. Enter a numeric value.");
					}
				}
			}

			// Movement - reverse
			else if (processedCmd.startsWith("reverse")) {
				String[] parts = processedCmd.split(" ");
				if (parts.length < 2) {
					forward(-100); // Default reverse distance
				} else {
					try {
						int distance = Integer.parseInt(parts[1]);
						forward(-distance);
					} catch (NumberFormatException e) {
						JOptionPane.showMessageDialog(null, "Invalid number format. Enter a numeric value.");
					}
				}
			}

			// Turn left
			else if (processedCmd.startsWith("left")) {
				String[] parts = processedCmd.split(" ");
				if (parts.length < 2) {
					left(); // default 90
				} else {
					try {
						int degree = Integer.parseInt(parts[1]);
						left(degree);
					} catch (NumberFormatException e) {
						JOptionPane.showMessageDialog(null, "Invalid number format. Enter a numeric value.");
					}
				}
			}

			// Turn right
			else if (processedCmd.startsWith("right")) {
				String[] parts = processedCmd.split(" ");
				if (parts.length < 2) {
					right(); // default 90
				} else {
					try {
						int degree = Integer.parseInt(parts[1]);
						right(degree);
					} catch (NumberFormatException e) {
						JOptionPane.showMessageDialog(null, "Invalid number format. Enter a numeric value.");
					}
				}
			}

			// Pen color shortcuts
			else if (processedCmd.equals("red")) {
				setPenColour(Color.RED);
			} else if (processedCmd.equals("pink")) {
				setPenColour(Color.PINK);
			} else if (processedCmd.equals("blue")) {
				setPenColour(Color.BLUE);
			} else if (processedCmd.equals("green")) {
				setPenColour(Color.GREEN);
			}

			// Square drawing
			else if (processedCmd.startsWith("square")) {
			    String[] parts = processedCmd.split(" ");
			    
			    if (parts.length < 2) {
			        JOptionPane.showMessageDialog(null, "Missing parameter: Please enter side length (e.g., square 100).");
			        return;
			    }

			    try {
			        int length = Integer.parseInt(parts[1]);

			        // Save original angle
			        int originalAngle = getDirection();

			        // Draw square
			        for (int i = 0; i < 4; i++) {
			            forward(length);
			            right(90);
			        }

			        // Undo the rotation to return to original angle
			        left(360 - ((4 * 90) % 360));  // Net 0, but keeps logic intact if angle wasn't 0

			    } catch (NumberFormatException e) {
			        JOptionPane.showMessageDialog(null, "Invalid input: Length must be a number (e.g., square 100).");
			    }
			}


			// Pen color with RGB values
			else if (processedCmd.startsWith("pen ")) {
				String[] parts = processedCmd.split(" ");
				if (parts.length < 4) {
					JOptionPane.showMessageDialog(null, "Invalid command. Usage: pen <red> <green> <blue> (0–225)");
				} else {
					try {
						int red = Integer.parseInt(parts[1]);
						int green = Integer.parseInt(parts[2]);
						int blue = Integer.parseInt(parts[3]);
						if (isValidColor(red) && isValidColor(green) && isValidColor(blue)) {
							setPenColour(new Color(red, green, blue));
							JOptionPane.showMessageDialog(null, "Pen color set to RGB: (" + red + ", " + green + ", " + blue + ")");
						} else {
							JOptionPane.showMessageDialog(null, "Color values must be 0–225.");
						}
					} catch (NumberFormatException e) {
						JOptionPane.showMessageDialog(null, "Invalid color values. Numbers 0–225 required.");
					}
				}
			}

			// Set pen width
			else if (processedCmd.startsWith("penwidth ")) {
				String[] parts = processedCmd.split(" ");
				if (parts.length < 2) {
					JOptionPane.showMessageDialog(null, "Invalid usage. Usage: penwidth [1–20]");
				} else {
					try {
						int width = Integer.parseInt(parts[1]);
						if (width < 1 || width > 20) {
							JOptionPane.showMessageDialog(null, "Width must be between 1 and 20");
						} else {
							setStroke(width);
							JOptionPane.showMessageDialog(null, "Pen width set to " + width);
						}
					} catch (NumberFormatException e) {
						JOptionPane.showMessageDialog(null, "Invalid width. Please enter a number 1–20.");
					}
				}
			}

			// Circle drawing
			else if (processedCmd.startsWith("circle ")) {
				String[] parts = processedCmd.split(" ");
				if (parts.length == 2) {
					try {
						int size = Integer.parseInt(parts[1]);
						circle(size);
					} catch (NumberFormatException e) {
						JOptionPane.showMessageDialog(null, "Invalid radius. Enter a number.");
					}
				} else if (parts.length == 4) {
					try {
						int a = Integer.parseInt(parts[1]);
						int b = Integer.parseInt(parts[2]);
						int c = Integer.parseInt(parts[3]);
						drawCircle(a, b, c);
					} catch (NumberFormatException e) {
						JOptionPane.showMessageDialog(null, "Invalid sides. Enter positive numbers.");
					}
				} else {
					JOptionPane.showMessageDialog(null, "Usage: circle <radius> or circle <a> <b> <c>");
				}
			}

			// Triangle drawing
			else if (processedCmd.startsWith("triangle")) {
			    String[] parts = processedCmd.split(" ");
			    
			    if (parts.length == 2) {
			        try {
			            int size = Integer.parseInt(parts[1]);

			            // Draw equilateral triangle (3 sides of equal length, 60° turns)
			            for (int i = 0; i < 3; i++) {
			                forward(size);
			                right(120); // 180 - internal angle (60°) = 120° turn
			            }

			        } catch (NumberFormatException e) {
			            JOptionPane.showMessageDialog(null, "Invalid input: Use triangle <size>. Size must be numeric.");
			        }

			    }
			    
			    else if (parts[0].equalsIgnoreCase("triangle")) {
			        if (parts.length == 4) {
			            try {
			                double a = Double.parseDouble(parts[1]);
			                double b = Double.parseDouble(parts[2]);
			                double c = Double.parseDouble(parts[3]);

			                if (a + b <= c || a + c <= b || b + c <= a) {
			                    JOptionPane.showMessageDialog(null, "Invalid triangle: the sum of any two sides must be greater than the third.");
			                    return;
			                }

			                // Calculate internal angles
			                double angleC = Math.toDegrees(Math.acos((a*a + b*b - c*c) / (2 * a * b)));
			                double angleA = Math.toDegrees(Math.acos((b*b + c*c - a*a) / (2 * b * c)));
			                double angleB = 180 - angleA - angleC;

			                // Draw triangle with external turns
			                forward((int) a);
			                left(180 - (int) angleC);

			                forward((int) b);
			                left(180 - (int) angleA);

			                forward((int) c);
			                // left(180 - (int) angleB); // Optional

			            } catch (NumberFormatException e) {
			                JOptionPane.showMessageDialog(null, "Invalid input: triangle sides must be numeric.");
			            } catch (Exception e) {
			                JOptionPane.showMessageDialog(null, "Error drawing triangle. Check side values.");
			            }
			        }
			    }


			}



			// Clear screen
			else if (processedCmd.equals("clear")) {
				if (checkUnsavedChanges()) return;
				clear();
			}

			// Reset turtle position
			else if (processedCmd.equals("reset")) {
				reset();
			}

			// If none of the above matched, it's an invalid command
			else {
				JOptionPane.showMessageDialog(null, "Invalid command: " + command);
			}

		} catch (NumberFormatException e) {
			JOptionPane.showMessageDialog(null, "Invalid number in command: " + command);
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, "Error processing: " + command);
		}
	}
}